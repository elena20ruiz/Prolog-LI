banner([ [x,x,.,x],
	 [x,x,.,x],
	 [x,x,.,x]
       ]).

pieces([[1,3,2],[2,3,1]]).
